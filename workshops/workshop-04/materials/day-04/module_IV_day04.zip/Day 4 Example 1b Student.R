# ==============================================================================
# DAY 4 - EXAMPLE 1B: Non-Linear Least Squares Calibration (Student Template)
# File Name: Day4_Example1b_Student.R
# Instructions: Complete each [TODO] prompt below during class.
# ==============================================================================

# Load Required Libraries and Setups (all stored in RSetupLibraries.R)
# -------------------------------------------------------------------------
if (!require("this.path")) install.packages("this.path")
source(file.path(this.path::this.dir(), "RSetupLibraries.R"))
# -------------------------------------------------------------------------

# -------------------------------------------------------------------------
# Step 0: Import Epidemic Data
# -------------------------------------------------------------------------

# Load synthetic dataset from Excel
epi_data <- read_excel("Data/SyntheticEpidemicData.xlsx")

Weeks    <- epi_data$epi_week
observed <- epi_data$reported_cases

t <- Weeks
cumObsCases <- cumsum(observed)


# -------------------------------------------------------------------------
# Step 1: Define Objective Function
# -------------------------------------------------------------------------

# Returns cumulative model prediction across time vector t
objectiveFunction <- function(params, t) {
  # Extract parameters to be estimated
  a <- params[1]
  b <- params[2]
  c <- params[3]
  
  # Model equation
  I <- a * exp(-0.5 * ((t - b) / c)^2)
  
  # TODO 1: Return the cumulative sum of model predictions (I)
  # Hint: Use the cumsum() function on vector 'I'
  cumsum(_______________?)
}


# -------------------------------------------------------------------------
# Step 2: Parameter Calibration using Levenberg-Marquardt (nls.lm)
# -------------------------------------------------------------------------

# Initial guesses
params_init <- c(
  a = 550,
  b = 10,
  c = 2
)

# TODO 2: Complete the residual formula inside nls.lm()
# Residual = Model Prediction - Observed Data
fit <- nls.lm(
  par = params_init,
  fn  = function(par) {
    
    # Calculate difference between model predictions and observed cumulative cases:
    objectiveFunction(par, Weeks) - _______________?
    
  },
  lower   = c(0, 0, 0),
  upper   = c(1000, 50, 10),
  control = nls.lm.control(
    ftol    = 1e-12,
    ptol    = 1e-10,
    maxiter = 500
  )
)


# -------------------------------------------------------------------------
# Step 3: Print Optimal Parameter Values
# -------------------------------------------------------------------------

# Extract calibrated parameter vector
params_optimal <- coef(fit)

cat("Optimal Parameters:\n")
print(params_optimal)


# -------------------------------------------------------------------------
# Step 4: Compute Goodness-of-Fit Statistics
# -------------------------------------------------------------------------

# Model evaluated at observation times using optimal parameters
model_fit <- objectiveFunction(params_optimal, Weeks)

# TODO 3a: Complete the RMSE formula: sqrt(mean((Observed - Model)^2))
RMSE <- sqrt(mean((cumObsCases - _______________?)^2))

# TODO 3b: Complete the MAE formula: mean(abs(Observed - Model))
MAE <- mean(abs(cumObsCases - _______________?))

# R-squared calculation
SStot <- sum((cumObsCases - mean(cumObsCases))^2)
SSres <- sum((cumObsCases - model_fit)^2)

# TODO 3c: Complete the R^2 formula: 1 - (SSres / SStot)
R2 <- 1 - (_______________? / SStot)

# Spearman rank correlation
correlation <- cor(cumObsCases, model_fit, method = "spearman")


# Print Summary Statistics
cat("\n── Goodness-of-Fit Summary ───────────────────\n")
cat(sprintf("RMSE                 = %.4f\n", RMSE))
cat(sprintf("MAE                  = %.4f\n", MAE))
cat(sprintf("R^2                  = %.4f\n", R2))
cat(sprintf("Spearman Correlation = %.4f\n", correlation))


# -------------------------------------------------------------------------
# Step 5: Prepare Data for Visualization
# -------------------------------------------------------------------------

# Compute initial (uncalibrated) cumulative cases for comparison
I_init <- objectiveFunction(params_init[1:3], t)

# Build plot dataframe
plotData <- data.frame(
  Week     = Weeks,
  Observed = cumObsCases,
  Unfitted = I_init,
  Fitted   = model_fit
)


# -------------------------------------------------------------------------
# Step 6: Plot Calibration Results
# -------------------------------------------------------------------------

# TODO 4: Complete the ggplot mapping for the Fitted (red line) trajectory
ggplot(plotData, aes(x = Week)) +
  # Observed data points
  geom_point(aes(y = Observed), size = 3) +
  # Initial (uncalibrated) model
  geom_line(aes(y = Unfitted), linewidth = 1, colour = "blue") +
  # Calibrated model line
  geom_line(aes(y = _______________?), linewidth = 1, colour = "red") +
  labs(
    title    = "Calibration of the Epidemic Model",
    subtitle = "Observed (black points) vs Initial (blue line) vs Fitted (red line)",
    x        = "Epidemic Week",
    y        = "Cumulative Cases"
  ) +
  annotate(
    "text",
    x = min(Weeks),
    y = max(cumObsCases),
    hjust = 0,
    vjust = 1,
    label = paste(
      sprintf("a = %.2f", params_optimal[1]),
      sprintf("\nb = %.2f", params_optimal[2]),
      sprintf("\nc = %.2f", params_optimal[3]),
      sprintf("\nRMSE = %.2f", RMSE),
      sprintf("\nMAE = %.4f", MAE),
      sprintf("\nR^2 = %.4f", R2),
      sprintf("\nCor = %.4f", correlation),
      sep = ""
    )
  ) +
  theme_bw()