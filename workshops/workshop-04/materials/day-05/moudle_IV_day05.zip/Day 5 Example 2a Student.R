# =========================================================================
# Script: Day5_Example2a_Students.R
# Course: Day 5 — Sensitivity Analysis and Modelling Interventions
# Topic: Simulating Non-Pharmaceutical Interventions (NPIs) on COVID-19
# =========================================================================

# -------------------------------------------------------------------------
# 1. Load Required Libraries and Environment Setup
# -------------------------------------------------------------------------
if (!require("this.path")) install.packages("this.path")
source(file.path(this.path::this.dir(), "RSetupLibraries.R"))

# -------------------------------------------------------------------------
# 2. Load Saved COVID-19 Calibration Results (Zone Kirkos)
# -------------------------------------------------------------------------
covid.calibration.results <- readRDS("Outputs/covid_calibration_results_Zone_Kirkos.rds")

# Unpack parameter and state vector objects
theta_hat <- covid.calibration.results$theta_hat
fixed     <- covid.calibration.results$fixed
ic        <- covid.calibration.results$ic
R0        <- covid.calibration.results$R0

cat("── Loaded COVID-19 Calibration Parameters ─────────────────\n")
cat(sprintf("Baseline Beta = %.6f | Baseline R0 = %.4f\n", theta_hat["beta"], R0))


# -------------------------------------------------------------------------
# 3. Dynamic ODE Model with Time-Dependent NPI Reduction
# -------------------------------------------------------------------------

# TASK 1 [FILL IN THE BLANKS]: Define the SEIR ODE Function with NPIs
# -------------------------------------------------------------------------
# HINT: Evaluate time-dependent transmission rate (beta_t):
# If time >= t_int, reduce transmission by factor (1 - eps_npi), else keep beta.

seir_npi <- function(time, state, parms) {
  with(as.list(c(state, parms)), {
    N <- S + E + I + R
    
    # FIXME: Implement piecewise beta_t logic using ifelse()
    beta_t <- ifelse(time >= t_int, ___? * (1 - ___?), beta)
    
    # FIXME: Calculate force of infection (lambda)
    lambda <- ___? * I / N
    
    # Differential equations
    dS <- b - lambda * S - mu * S
    dE <- lambda * S - (mu + omega) * E
    dI <- omega * E - (gamma + mu + sigma) * I
    dR <- gamma * I - mu * R
    dC <- omega * E  # Cumulative incident cases tracking
    
    list(c(dS, dE, dI, dR, dC))
  })
}


# -------------------------------------------------------------------------
# 4. Run Multi-Scenario Simulation Experiments
# -------------------------------------------------------------------------

intervention_start_week <- 35 

# TASK 2 [FILL IN THE BLANKS]: Complete Scenario Wrapper Function
# -------------------------------------------------------------------------
run_npi <- function(eps, label) {
  # Build full parameter vector for scenario
  p <- c(theta_hat, fixed, eps_npi = eps, t_int = intervention_start_week)
  
  # FIXME: Solve the ODE system using ode() over weeks 1 to 120
  out <- ode(y = ic, times = 1:120, func = ___?, parms = p, method = "lsoda")
  
  # Format as dataframe
  data.frame(
    Week     = out[, "time"], 
    I        = out[, "I"], 
    CumC     = out[, "C"], 
    Scenario = label
  )
}

# Bind simulation outputs across four intervention scenarios (0%, 25%, 50%, 75% reductions)
npi_df <- bind_rows(
  run_npi(0.00, "Baseline"),
  run_npi(0.25, "NPI: 25% beta reduction"),
  run_npi(0.50, "NPI: 50% beta reduction"),
  run_npi(0.75, "NPI: 75% beta reduction")
)


# -------------------------------------------------------------------------
# 5. Visualization: Active Infectious Trajectories Across Scenarios
# -------------------------------------------------------------------------

# TASK 3 [CODE COMPLETION]: Render Comparative Line Plot
# -------------------------------------------------------------------------
p_npi <- ggplot(npi_df, aes(x = Week, y = I, colour = Scenario)) +
  geom_line(linewidth = 1.1) +
  geom_vline(xintercept = intervention_start_week, linetype = "dashed", colour = "grey50") +
  annotate(
    "text", 
    x = intervention_start_week + 1, 
    y = max(npi_df$I) * 0.9, 
    label = "NPI Implementation",
    hjust = 0, 
    size = 3.5, 
    colour = "grey40"
  ) +
  scale_colour_manual(
    values = c(
      "Baseline"                = "#C94A3F",
      "NPI: 25% beta reduction" = "#DB8802",
      "NPI: 50% beta reduction" = "#42529B",
      "NPI: 75% beta reduction" = "#2E7D32"
    )
  ) +
  labs(
    title = "Effect of Non-Pharmaceutical Interventions on Active COVID-19 Cases",
    subtitle = sprintf("Intervention triggered at Week %d across variable effectiveness levels", intervention_start_week),
    x = "Week", 
    y = "Active Infectious Individuals (I)",
    colour = "Intervention Scenario"
  ) +
  theme_arbo

print(p_npi)