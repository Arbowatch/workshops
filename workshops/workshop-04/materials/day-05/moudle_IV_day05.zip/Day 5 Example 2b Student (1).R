# =========================================================================
# Script: Day5_Example2b_Students.R
# Course: Day 5 — Sensitivity Analysis and Modelling Interventions 
# Topic: SVEIR COVID-19 Vaccination Dynamics & Herd Immunity Analysis
# =========================================================================

# -------------------------------------------------------------------------
# 1. Load Required Libraries and Environment Setup
# -------------------------------------------------------------------------
if (!require("this.path")) install.packages("this.path")
source(file.path(this.path::this.dir(), "RSetupLibraries.R"))

# -------------------------------------------------------------------------
# 2. Load Saved COVID-19 Calibration Results (Zone Kirkos)
# -------------------------------------------------------------------------
covid.calibration.results <- readRDS("Outputs/covid_calibration_results_Zone_Kirkos.rds")

# Unpack calibrated parameters and state initial conditions
theta_hat <- covid.calibration.results$theta_hat
fixed     <- covid.calibration.results$fixed
ic        <- covid.calibration.results$ic
R0        <- covid.calibration.results$R0

cat("── Loaded COVID-19 Calibration Results ───────────────────\n")
cat(sprintf("Baseline Beta = %.6f | Baseline R0 = %.4f\n", theta_hat["beta"], R0))


# -------------------------------------------------------------------------
# 3. Dynamic SVEIR ODE Model with Vaccination
# -------------------------------------------------------------------------

# TASK 1 [FILL IN THE BLANKS]: Implement the SVEIR Differential Equations
# -------------------------------------------------------------------------
# HINT: SVEIR System Equations:
# Force of infection: lambda = beta * I / N
# Vaccination rate: nu_t = nu if time >= vaccination_start_week else 0
# dS = b - lambda*S - nu_t*S - mu*S
# dV = nu_t*S - (1 - eps_v)*lambda*V - mu*V
# dE = lambda*S + (1 - eps_v)*lambda*V - (mu + omega)*E

sveir_covid <- function(time, state, parms) {
  with(as.list(c(state, parms)), {
    N <- S + V + E + I + R
    lambda <- beta * I / N
    
    # Piecewise vaccination rollout rate
    nu_t <- ifelse(time >= vaccination_start_week, nu, 0)
    
    # Differential equations
    # FIXME: Complete S, V, and E derivative formulations
    dS <- b - lambda * S - nu_t * S - mu * S
    dV <- ___? * S - (1 - ___? ) * lambda * V - mu * V
    dE <- lambda * S + (1 - eps_v) * lambda * V - (___? + ___?) * E
    dI <- omega * E - (gamma + mu + sigma) * I
    dR <- gamma * I - mu * R
    dC <- omega * E  # Track cumulative cases
    
    list(c(dS, dV, dE, dI, dR, dC))
  })
}


# -------------------------------------------------------------------------
# 4. Run Multi-Scenario Rollout Simulations
# -------------------------------------------------------------------------

vaccination_start_week <- 10
tspan <- 1:120 # Weeks 1 to 120

# TASK 2 [FILL IN THE BLANKS]: Scenario Wrapper Function
# -------------------------------------------------------------------------
run_vacc <- function(nu_v, eps_v, label) {
  ic_v <- c(
    S = unname(ic["S"]), 
    V = 0, 
    E = unname(ic["E"]),
    I = unname(ic["I"]), 
    R = unname(ic["R"]), 
    C = unname(ic["C"])
  )
  
  p <- c(
    theta_hat, 
    fixed,
    nu = nu_v,                         # Weekly vaccination rate
    eps_v = eps_v,                     # Vaccine efficacy
    vaccination_start_week = vaccination_start_week
  )
  
  # FIXME: Solve SVEIR system via ode()
  out <- ode(y = ic_v, times = tspan, func = ___?, parms = p, method = "lsoda")
  
  data.frame(
    Week     = out[, "time"], 
    S        = out[, "S"], 
    V        = out[, "V"], 
    I        = out[, "I"],
    CumC     = out[, "C"], 
    Scenario = label
  )
}

# Bind baseline and three vaccination scenarios
vacc_df <- bind_rows(
  run_vacc(nu_v = 0.000, eps_v = 0.00, label = "No vaccination"),
  run_vacc(nu_v = 0.005, eps_v = 0.50, label = "nu=0.5%/wk,\ne=50%"),
  run_vacc(nu_v = 0.010, eps_v = 0.50, label = "nu=1%/wk,\ne=50%"),
  run_vacc(nu_v = 0.010, eps_v = 0.70, label = "nu=1%/wk,\ne=70%")
)


# -------------------------------------------------------------------------
# 5. Visualization: Active Infectious Cases Trajectory
# -------------------------------------------------------------------------
p_vacc <- ggplot(vacc_df, aes(Week, I, colour = Scenario)) +
  geom_line(linewidth = 1.1) +
  geom_vline(xintercept = vaccination_start_week, linetype = "dashed", colour = "grey50") +
  annotate(
    "text", x = vaccination_start_week + 1, y = max(vacc_df$I) * 0.95, 
    hjust = 0, size = 3.5, colour = "grey40",
    label = sprintf("Vaccination\nstarts\nweek %d", vaccination_start_week)
  ) +
  scale_colour_brewer(palette = "Set1") +
  guides(colour = guide_legend(
    ncol = 2, byrow = TRUE,
    keywidth = unit(1.2, "cm"), keyheight = unit(1.0, "cm"),
    label.theme = element_text(size = 10, lineheight = 1.2)
  )) +
  labs(
    title = "Vaccination Impact — SVEIR COVID-19 Model",
    subtitle = sprintf("Vaccination introduced at week %d across varying rollout speeds and efficacies", vaccination_start_week),
    x = "Week", y = "Infectious Cases (I)", colour = "Scenario"
  ) +
  theme_arbo +
  theme(
    legend.position = "bottom",
    legend.title    = element_text(face = "bold"),
    legend.text     = element_text(size = 10),
    legend.key.width = unit(1.5, "cm"),
    legend.spacing.x = unit(0.3, "cm")
  )

print(p_vacc)


# -------------------------------------------------------------------------
# 6. Herd Immunity Threshold (HIT) & Rollout Timeline Calculations
# -------------------------------------------------------------------------

# TASK 3 [FILL IN THE BLANKS]: Herd Immunity & Coverage Calculations
# -------------------------------------------------------------------------
# Formulae:
# Herd Immunity Threshold: p_c = 1 - (1 / R0)
# Critical Coverage: p* = p_c / eps_v
# Weeks required: weeks = p* / nu

# FIXME: Compute Herd Immunity Threshold (p_c)
p_c <- 1 - (1 / max(1, ___?))
cat("Herd Immunity Threshold (p_c):", round(p_c * 100, 2), "%\n")

# FIXME: Calculate critical population coverage p* for eps_v = 50% and 70%
p_star_50 <- ___? / 0.50
p_star_70 <- ___? / 0.70

cat("Required Coverage at 50% efficacy (p*):", round(p_star_50 * 100, 2), "%\n")
cat("Required Coverage at 70% efficacy (p*):", round(p_star_70 * 100, 2), "%\n\n")

# Calculate duration in weeks needed to achieve required threshold p*
weeks_05_eps50 <- p_star_50 / 0.005
weeks_10_eps50 <- p_star_50 / 0.010

weeks_05_eps70 <- p_star_70 / 0.005
weeks_10_eps70 <- p_star_70 / 0.010

timing_summary <- data.frame(
  Efficacy         = c("50%", "50%", "70%", "70%"),
  Vaccination_Rate = c("0.5%/wk", "1.0%/wk", "0.5%/wk", "1.0%/wk"),
  Weeks_Needed     = round(c(weeks_05_eps50, weeks_10_eps50, weeks_05_eps70, weeks_10_eps70), 1)
)

kable(
  timing_summary, 
  col.names = c("Efficacy", "Vaccination Rate", "Weeks Needed"),
  caption = "Table 1: Time required (weeks) to achieve Herd Immunity Threshold across scenarios"
) %>% kable_styling(full_width = FALSE)


# -------------------------------------------------------------------------
# 7. Summary Table: Cumulative Cases Averted
# -------------------------------------------------------------------------
baseline_cases <- max(vacc_df$CumC[vacc_df$Scenario == "No vaccination"])

cases_summary <- vacc_df %>%
  group_by(Scenario) %>%
  summarise(
    Total_Cases     = max(CumC),
    Peak_Infectious = max(I),
    Cases_Averted   = baseline_cases - max(CumC)
  )

kable(
  cases_summary, 
  col.names = c("Scenario", "Total Cases", "Peak Cases", "Cases Averted"),
  caption = "Table 2: Summary of COVID-19 Cases Averted across Vaccination Scenarios"
) %>% kable_styling(full_width = FALSE)


# -------------------------------------------------------------------------
# 8. Sensitivity Analysis: Impact of Vaccine Efficacy
# -------------------------------------------------------------------------
# Evaluate fixed rollout rate (1%/week) across eps_v = 50%, 60%, and 70%
sens_50 <- run_vacc(nu_v = 0.010, eps_v = 0.50, label = "Efficacy: 50%")
sens_60 <- run_vacc(nu_v = 0.010, eps_v = 0.60, label = "Efficacy: 60%")
sens_70 <- run_vacc(nu_v = 0.010, eps_v = 0.70, label = "Efficacy: 70%")

sens_df <- bind_rows(
  filter(vacc_df, Scenario == "No vaccination"),
  sens_50, 
  sens_60, 
  sens_70
)

peak_sensitivity <- sens_df %>%
  group_by(Scenario) %>%
  summarise(
    Peak_Infectious = max(I),
    Total_Cases     = max(CumC),
    Cases_Averted   = baseline_cases - max(CumC)
  )

kable(
  peak_sensitivity, 
  col.names = c("Scenario", "Peak Infectious", "Total Cases", "Cases Averted"),
  caption = "Table 3: Sensitivity of Peak Burden and Cumulative Cases to Vaccine Efficacy"
) %>% kable_styling(full_width = FALSE)

p_sens <- ggplot(sens_df, aes(x = Week, y = I, colour = Scenario)) +
  geom_line(linewidth = 1.1) +
  geom_vline(xintercept = vaccination_start_week, linetype = "dashed", colour = "grey50") +
  scale_colour_brewer(palette = "Set1") +
  labs(
    title = "Sensitivity of Epidemic Trajectory to Vaccine Efficacy",
    subtitle = sprintf("Fixed rollout rate of 1%% per week starting at Week %d", vaccination_start_week),
    x = "Week", y = "Infectious Cases (I)", colour = "Efficacy Scenario"
  ) +
  theme_arbo +
  theme(
    legend.position = "bottom",
    legend.title    = element_text(face = "bold"),
    legend.text     = element_text(size = 10),
    legend.key.width = unit(1.5, "cm"),
    legend.spacing.x = unit(0.3, "cm")
  )

print(p_sens)