# ── 1. Set current working directory ───────────────────────────────────────────
# Install if not already available
if (!require("this.path")) install.packages("this.path")
# Set working directory to this script's location
setwd(this.path::this.dir())
print(getwd())

# ── 2. knitr global options ───────────────────────────────────────────
knitr::opts_chunk$set(
  echo    = TRUE,
  warning = FALSE,
  message = FALSE,
  fig.width  = 10,
  fig.height = 5.5,
  fig.align  = "center",
  cache   = FALSE
)

# ── 3. Core libraries ──────────────────────────────────────────────────────────
library(deSolve)       # Numerical ODE/PDE solver
library(minpack.lm)    # Levenberg-Marquardt nonlinear least squares
library(ggplot2)       # Publication-quality plots
library(readxl)        # Read Excel files
library(readr)         # Fast and friendly reading of rectangular data (includes read_csv)
library(dplyr)         # Data manipulation
library(tidyr)         # Data reshaping
library(purrr)         # Functional programming
library(knitr)         # Reporting
library(kableExtra)    # Formatted tables
library(gridExtra)     # Multi-panel plots
library(scales)        # Axis formatting
library(sensitivity)   # Global sensitivity (PRCC/Sobol)
library(lhs)           # Latin Hypercube Sampling

# Optional for MCMC (install if needed):
# install.packages(c("FME","bbmle"))
# library(FME); library(bbmle)

# ── 4. Custom ggplot theme ────────────────────────────────────────────────────
theme_arbo <- theme_minimal(base_size = 13) +
  theme(
    plot.title    = element_text(colour = "#C94A3F", face = "bold", size = 14),
    plot.subtitle = element_text(colour = "#44546A", size = 11),
    axis.title    = element_text(colour = "#44546A"),
    strip.text    = element_text(face = "bold"),
    legend.position = "bottom"
  )

# 5. Customized plotting function
plot_model_fit <- function(
    ode_func,
    ic,
    fixed,
    theta,
    t_obs,
    y_obs,
    state = "C",
    title = "Calibration + Forecast",
    xlabel = "Epidemiological Week",
    ylabel = "Cumulative Cases",
    forecast = 6) {
  
  t_fc <- seq(min(t_obs), max(t_obs) + forecast, by = 1)
  
  # Model predicted
  out_fc <- ode(
    y = ic,
    times = t_fc,
    func = ode_func,
    parms = c(theta, fixed),
    method = "lsoda"
  )
  
  # df
  df_model <- data.frame(Week=t_fc, Cases=out_fc[, state], Source="Model")
  df_real  <- data.frame(Week=t_obs, Cases=y_obs, Source="Observed")
  
  # Plot
  ggplot() +
    geom_line(
      data = df_model,
      aes(Week, Cases, colour = "Model"),
      linewidth = 1.3
    ) +
    geom_point(
      data = df_real,
      aes(Week, Cases, colour = "Observed"),
      size = 2.5
    ) +
    geom_vline(
      xintercept = max(t_obs),
      linetype = "dashed",
      colour = "grey50"
    ) +
    annotate(
      "text", x=max(t_obs), y=max(y_obs)*0.5, hjust=0, size=3.8,
      colour="grey40", label="<- Forecast"
    ) +
    scale_colour_manual(
      values = c(Model = "#1565C0",
                 Observed = "#B71C1C"),
      name = ""
    ) +
    labs(
      title = title,
      subtitle="Blue line = model fit; Red points = observed cumulative cases",
      x = xlabel,
      y = ylabel
    ) +
    theme_arbo
}