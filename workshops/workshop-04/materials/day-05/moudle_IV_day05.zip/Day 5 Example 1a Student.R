# =========================================================================
# Script: Day5_Example1a_Students.R
# Course: Day 5 — Sensitivity Analysis and Modelling Interventions
# Topic: Local Sensitivity Analysis of R0 for Calibrated COVID-19 Model
# =========================================================================

# -------------------------------------------------------------------------
# 1. Load Required Libraries and Environment Setup
# -------------------------------------------------------------------------
if (!require("this.path")) install.packages("this.path")
source(file.path(this.path::this.dir(), "RSetupLibraries.R"))

# -------------------------------------------------------------------------
# 2. Load Calibrated COVID-19 Results (Zone Kirkos)
# -------------------------------------------------------------------------
covid.calibration.results <- readRDS("Outputs/covid_calibration_results_Zone_Kirkos.rds")

# Unpack parameter objects
theta_hat <- covid.calibration.results$theta_hat
fixed     <- covid.calibration.results$fixed
R0_cal    <- covid.calibration.results$R0

# Print loaded summary
cat("── Loaded Calibration Metrics ───────────────────────\n")
cat(sprintf("Calibrated Beta = %.6f | Baseline R0 = %.6f\n", theta_hat["beta"], R0_cal))

# Assign individual parameter variables
beta0  <- unname(theta_hat["beta"])
omega0 <- unname(fixed$omega)
gamma0 <- unname(fixed$gamma)
mu0    <- unname(fixed$mu)
b0     <- unname(fixed$b)
sigma0 <- unname(fixed$sigma)


# -------------------------------------------------------------------------
# 3. Analytical Sensitivity Analysis
# -------------------------------------------------------------------------

# TASK 1 [FILL IN THE BLANKS]: Construct the R0 Symbolic Expression
# -------------------------------------------------------------------------
# HINT: The dynamic formula for SEIR COVID-19 R0 is given by:
# R0 = (beta * omega) / [(mu + omega) * (mu + sigma + gamma)]

R0_expr <- expression(
  # FIXME: Replace '___?' with appropriate parameters (beta, omega, mu, sigma, gamma)
  ___? * ___? / ((___? + ___?) * (___? + ___? + ___?))
)

# List of parameters to differentiate with respect to R0
pars <- c("beta", "omega", "gamma", "sigma", "mu")


# TASK 2 [FILL IN THE BLANKS]: Compute Symbolic Partial Derivatives
# -------------------------------------------------------------------------
# HINT: Use R's D() function wrapped inside lapply() across vector 'pars'

partials_expr <- lapply(pars, function(p) {
  # FIXME: Differentiate R0_expr with respect to variable 'p'
  D(___?, ___?)
})
names(partials_expr) <- pars

# Parameter dictionary for numerical evaluation
par_values <- list(
  beta  = beta0,
  omega = omega0,
  gamma = gamma0,
  sigma = sigma0,
  mu    = mu0,
  b     = b0
)


# TASK 3 [FILL IN THE BLANKS]: Calculate Normalized Sensitivity Indices
# -------------------------------------------------------------------------
# Formula: S_p = (∂R0 / ∂p) * (p / R0)

# Evaluate baseline R0 value
R0_val <- eval(R0_expr, envir = par_values)

# Evaluate numerical partial derivatives (∂R0 / ∂p)
partials <- sapply(partials_expr, function(expr) {
  eval(expr, envir = par_values)
})

param_vec <- unlist(par_values[pars])

# FIXME: Calculate normalized sensitivity index (si) using partials, param_vec, and R0_val
si <- ___? * (___? / ___?)

cat("\n── Computed Normalized Sensitivity Indices (Elasticities) ──\n")
print(round(si, 4))


# -------------------------------------------------------------------------
# 4. Visualization: Sensitivity Tornado Chart
# -------------------------------------------------------------------------
# Prepare summary dataframe for plotting
df_si <- data.frame(
  Parameter = names(si),
  Index     = as.numeric(si),
  Direction = ifelse(as.numeric(si) > 0, "Positive", "Negative")
)

# Render Tornado Plot
p_tornado <- ggplot(df_si |> arrange(abs(Index)),
                    aes(x = reorder(Parameter, abs(Index)), y = Index, fill = Direction)) +
  geom_col(width = 0.6) +
  geom_hline(yintercept = 0, linewidth = 0.5, linetype = "dashed") +
  coord_flip() +
  scale_fill_manual(values = c("Positive" = "#C94A3F", "Negative" = "#42529B")) +
  labs(
    title = "Tornado Chart: Sensitivity of R0 to Parameters (COVID-19)",
    subtitle = "Parameters ranked by magnitude of impact on R0",
    x = "Parameter",
    y = "Normalized Sensitivity Index (Elasticity)"
  ) +
  theme_arbo + 
  theme(legend.position = "none")

print(p_tornado)