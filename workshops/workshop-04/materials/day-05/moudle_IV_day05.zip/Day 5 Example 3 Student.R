# =========================================================================
# Script: Day5_Example3_Students.R
# Course: Day 5 — Advanced Dynamics & Sensitivity Analysis
# Topic: Stochastic Differential Equation (SDE) Modeling for Vector-Borne Diseases
# Method: Euler-Maruyama Numerical Integration with Environmental Noise
# =========================================================================

# -------------------------------------------------------------------------
# 1. Load Required Libraries and Environment Setup
# -------------------------------------------------------------------------
if (!require("this.path")) install.packages("this.path")
source(file.path(this.path::this.dir(), "RSetupLibraries.R"))


# -------------------------------------------------------------------------
# 2. Define the Vector-Host SDE Simulation Function (Euler-Maruyama)
# -------------------------------------------------------------------------

# TASK 1 [FILL IN THE BLANKS]: Complete Wiener Increment and SDE Updates
# -------------------------------------------------------------------------
# SDE System Formulation (Ito's Stochastic Differential Equation):
# dX(t) = f(X, t) dt + g(X, t) dB(t)
#
# Where:
# - f(X, t) is the deterministic drift coefficient (from standard ODEs)
# - g(X, t) is the diffusion (stochastic noise) coefficient
# - dB(t) ~ N(0, dt) is the Wiener process increment (Brownian motion)

simulate_malaria_sde <- function(
    t_end = 180,           # Total simulation time (days)
    dt    = 1/24,          # Hourly time-step size (dt = 1/24 days)
    # Initial Conditions (Humans H, Vectors V)
    SH0 = 90,   IH0 = 10,  RH0 = 0,
    SV0 = 9000, IV0 = 1000,
    # System Parameters
    b        = 1/5555,                   # Human recruitment rate
    beta0    = mean(c(0.26, 0.67)),      # Baseline transmission rate
    alpha_vh = mean(c(0.001, 0.35)),     # Transmission efficiency: vector -> human
    alpha_hv = mean(c(0.1, 0.75)),      # Transmission efficiency: human -> vector
    mu       = 1 / (60 * 52),            # Natural human mortality rate
    sigma    = 0.005,                    # Disease-induced human mortality
    gamma    = 1 / (4 / 7),              # Human recovery rate
    phi      = 1 / 3000,                 # Mosquito recruitment rate
    mu_v     = 1 / (14 / 7),             # Mosquito natural mortality rate
    a        = 0.5,                      # Noise intensity scaling parameter
    nonneg   = TRUE,                     # Truncate negative state values to 0
    seed     = 42                        # Set seed for reproducibility
){
  set.seed(seed)
  
  times <- seq(0, t_end, by = dt)
  n     <- length(times)
  
  # Allocate memory for state vectors
  SH <- numeric(n); IH <- numeric(n); RH <- numeric(n)
  SV <- numeric(n); IV <- numeric(n)
  
  # Set initial conditions
  SH[1] <- SH0; IH[1] <- IH0; RH[1] <- RH0
  SV[1] <- SV0; IV[1] <- IV0
  
  # Numerical integration loop via Euler-Maruyama scheme
  for (k in 1:(n - 1)) {
    N <- SH[k] + IH[k] + RH[k]
    M <- SV[k] + IV[k]
    
    # Avoid division by zero
    N <- max(N, .Machine$double.eps)
    M <- max(M, .Machine$double.eps)
    
    # FIXME: Generate standard Wiener increment dB ~ N(0, dt)
    # HINT: Standard deviation of Brownian motion over interval dt is sqrt(dt)
    dB <- ___? * rnorm(1)
    
    # ----- Drift Terms f(X, t): Standard ODE Rates -----
    lambda_H <- alpha_vh * beta0 * (IV[k] / M)  # Force of infection on humans
    f_SH <- b - lambda_H * SH[k] - mu * SH[k]
    f_IH <- lambda_H * SH[k] - (mu + sigma + gamma) * IH[k]
    f_RH <- gamma * IH[k] - mu * RH[k]
    
    lambda_V <- alpha_hv * beta0 * (IH[k] / N)  # Force of infection on mosquitoes
    f_SV <- phi - lambda_V * SV[k] - mu_v * SV[k]
    f_IV <- lambda_V * SV[k] - mu_v * IV[k]
    
    # ----- Diffusion Terms g(X, t): Stochastic Noise Coefficients -----
    g_SH <- - a * alpha_vh * (IV[k] / M) * SH[k]
    g_IH <- + a * alpha_vh * (IV[k] / M) * SH[k]
    g_SV <- - a * alpha_hv * (IH[k] / N) * SV[k]
    g_IV <- + a * alpha_hv * (IH[k] / N) * SV[k]
    
    # ----- Euler-Maruyama State Updates -----
    # FIXME: Complete the stochastic updates X[k+1] = X[k] + f*dt + g*dB
    SH[k+1] <- SH[k] + f_SH * dt + ___? * dB
    IH[k+1] <- IH[k] + f_IH * dt + ___? * dB
    RH[k+1] <- RH[k] + f_RH * dt  # Deterministic recovery transition
    
    SV[k+1] <- SV[k] + f_SV * dt + ___? * dB
    IV[k+1] <- IV[k] + f_IV * dt + ___? * dB
    
    # Enforce non-negativity boundary conditions
    if (nonneg) {
      SH[k+1] <- max(SH[k+1], 0)
      IH[k+1] <- max(IH[k+1], 0)
      RH[k+1] <- max(RH[k+1], 0)
      SV[k+1] <- max(SV[k+1], 0)
      IV[k+1] <- max(IV[k+1], 0)
    }
  }
  
  data.frame(
    time = times,
    SH = SH, IH = IH, RH = RH,
    SV = SV, IV = IV,
    NH = SH + IH + RH,
    MV = SV + IV
  )
}


# -------------------------------------------------------------------------
# 3. Single Realization Run
# -------------------------------------------------------------------------
cat("── Running Baseline SDE Simulation ─────────────────────────\n")
solution <- simulate_malaria_sde(t_end = 180, dt = 1/24, a = 0.5, seed = 42)


# -------------------------------------------------------------------------
# 4. Base Graphics Visualization
# -------------------------------------------------------------------------
op <- par(mfrow = c(2, 2), mar = c(4, 4, 2.5, 1))

plot(solution$time, solution$SH, col = "darkgreen", type = "l", lwd = 1.2,
     xlab = "Time (days)", ylab = "Susceptible Humans (SH)", 
     main = "Susceptible Human Population")

plot(solution$time, solution$IH, col = "firebrick", type = "l", lwd = 1.2,
     xlab = "Time (days)", ylab = "Infectious Humans (IH)", 
     main = "Infectious Human Population")

plot(solution$time, solution$SV, col = "dodgerblue", type = "l", lwd = 1.2,
     xlab = "Time (days)", ylab = "Susceptible Vectors (SV)", 
     main = "Susceptible Vector Population")

plot(solution$time, solution$IV, col = "purple", type = "l", lwd = 1.2,
     xlab = "Time (days)", ylab = "Infectious Vectors (IV)", 
     main = "Infectious Vector Population")

par(op)


# -------------------------------------------------------------------------
# 5. Ensemble Simulation & ggplot2 Uncertainty Bands
# -------------------------------------------------------------------------

# TASK 2 [FILL IN THE BLANKS]: Run Monte Carlo SDE Realizations
# -------------------------------------------------------------------------
num_sims <- 20
ensemble_list <- vector("list", num_sims)

for (i in 1:num_sims) {
  # Vary seed across iterations to sample distinct Brownian motion paths
  sim_data <- simulate_malaria_sde(
    t_end = 180, dt = 1/24, a = 0.5, seed = ___? + i
  )
  sim_data$sim_id <- factor(i)
  ensemble_list[[i]] <- sim_data
}

ensemble_df <- bind_rows(ensemble_list)

# Calculate summary statistics across realizations at each time point
ensemble_summary <- ensemble_df %>%
  group_by(time) %>%
  summarise(
    IH_mean  = mean(IH),
    IH_lower = quantile(IH, 0.025),
    IH_upper = quantile(IH, 0.975),
    IV_mean  = mean(IV),
    IV_lower = quantile(IV, 0.025),
    IV_upper = quantile(IV, 0.975)
  )

# Plot Human Infections Ensemble with 95% Confidence Envelope
p_ensemble_human <- ggplot() +
  geom_line(data = ensemble_df, aes(x = time, y = IH, group = sim_id), 
            colour = "firebrick", alpha = 0.25, linewidth = 0.5) +
  geom_ribbon(data = ensemble_summary, aes(x = time, ymin = IH_lower, ymax = IH_upper), 
              fill = "darkred", alpha = 0.2) +
  geom_line(data = ensemble_summary, aes(x = time, y = IH_mean), 
            colour = "darkred", linewidth = 1.2) +
  labs(
    title = "SDE Malaria Trajectories: Human Infectious Cases (20 Realizations)",
    subtitle = "Light lines = individual SDE paths | Ribbon = 95% Envelope | Solid line = Ensemble Mean",
    x = "Time (days)", y = "Infectious Humans (IH)"
  ) +
  theme_arbo

print(p_ensemble_human)