# ==============================================================================
# DAY 4 - EXAMPLE 1A: Initial Epidemic Curve Modeling (Student Template)
# File Name: Day4_Example1a_Student.R
# Instructions: Complete each [TODO] prompt below during class.
# ==============================================================================

# Load Required Libraries and Setups (all stored in RSetupLibraries.R)
# -------------------------------------------------------------------------
if (!require("this.path")) install.packages("this.path")
source(file.path(this.path::this.dir(), "RSetupLibraries.R"))
# -------------------------------------------------------------------------

# -------------------------------------------------------------------------
# Step 1: Import Epidemic Data
# -------------------------------------------------------------------------

# Load synthetic dataset from Excel
epi_data <- read_excel("Data/SyntheticEpidemicData.xlsx")

# TODO 1: Extract the 'reported_cases' column into the 'observed' variable
# Hint: Use the $ operator to pull out a column from epi_data
Weeks    <- epi_data$epi_week
observed <- _______________?  # Pull 'reported_cases' column here

t <- Weeks


# -------------------------------------------------------------------------
# Step 2: Define Initial (Uncalibrated) Epidemic Model
# -------------------------------------------------------------------------

# Initial parameter choices
a <- 550      # Peak incidence (height of curve)
b <- 10       # Peak week (center of curve)
c <- 2        # Spread of epidemic (width of curve)

# TODO 2: Complete the Gaussian epidemic curve equation inside the function
# Math formula: I(t) = a * exp(-0.5 * ((t - b)/c)^2)
I <- function(t) {
  
  # Fill in the mathematical expression below:
  _______________?
  
}

# Generate initial model predictions across time t
predicted <- round(I(t))


# -------------------------------------------------------------------------
# Step 3: Compute Cumulative Cases
# -------------------------------------------------------------------------

# TODO 3: Compute cumulative sums for observed and predicted cases
# Hint: Use the cumsum() function on the 'observed' and 'predicted' vectors
cumObsCases  <- cumsum(_______________?)
cumPredCases <- _______________?(predicted)


# -------------------------------------------------------------------------
# Step 4: Plot Initial (Uncalibrated) Model vs Observed Data
# -------------------------------------------------------------------------

# TODO 4a: Map 'Observed' to the y-axis in geom_point for Plot 1
p1 <- ggplot(
  data.frame(Week = t, Observed = observed, Predicted = predicted),
  aes(x = Week)
) +
  geom_point(aes(y = _______________?), size = 2) +
  geom_line(aes(y = Predicted), colour = "blue", linewidth = 1) +
  labs(
    title = "Weekly Reported Cases",
    x     = "Epidemic Week",
    y     = "Number of Cases"
  ) +
  theme_bw()


# TODO 4b: Map 'Predicted' to the y-axis in geom_line for Plot 2
p2 <- ggplot(
  data.frame(Week = t, Observed = cumObsCases, Predicted = cumPredCases),
  aes(x = Week)
) +
  geom_point(aes(y = Observed), size = 2) +
  geom_line(aes(y = _______________?), colour = "blue", linewidth = 1) +
  labs(
    title = "Cumulative Reported Cases",
    x     = "Epidemic Week",
    y     = "Cumulative Cases"
  ) +
  theme_bw()


# Render both plots side by side
grid.arrange(p1, p2, ncol = 2)