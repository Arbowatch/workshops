# ==============================================================================
# DAY 4 - EXAMPLE 2: Real COVID-19 Data Calibration (SEIR ODE Model)
# File Name: Day4_Example2_Student.R
# Instructions: Complete each [TODO] prompt below during class.
# ==============================================================================

# Load Required Libraries and Setups (all stored in RSetupLibraries.R)
# -------------------------------------------------------------------------
if (!require("this.path")) install.packages("this.path")
source(file.path(this.path::this.dir(), "RSetupLibraries.R"))
# -------------------------------------------------------------------------

# -------------------------------------------------------------------------
# STEP 1: Load Real COVID-19 Surveillance Data
# -------------------------------------------------------------------------

# Read line-list dataset
cov_raw <- read_excel("Data/COVID_Data.xlsx")

# Filter dataset for Kirkos subcity/zone
sub <- cov_raw[cov_raw[["Zone/Subcit"]] == "Kirkos", ]

# Aggregate case counts by Epidemiological Week
covid_obs <- sub %>%
  group_by(Week) %>%
  summarise(total_cases = n(), .groups = "drop") %>%
  arrange(Week)

# TODO 1: Compute cumulative case counts for model calibration
# Hint: Apply the cumsum() function on total_cases
covid_obs$CumCases <- cumsum(covid_obs$_______________?)


# -------------------------------------------------------------------------
# STEP 2: Define SEIR Differential Equations System
# -------------------------------------------------------------------------

seir_covid <- function(time, state, parms) {
  with(as.list(c(state, parms)), {
    N      <- S + E + I + R
    lambda <- beta * I / N   # Transmission rate (force of infection)
    
    # Differential equations
    dS <- b - lambda * S - mu * S
    dE <- lambda * S - (mu + omega) * E
    
    # TODO 2: Complete the infectious compartment equation (dI)
    # Gain from Exposed (omega*E) minus loss from recovery (gamma*I), natural mortality (mu*I), & disease death (sigma*I)
    dI <- omega * E - (gamma + mu + _______________?) * I
    
    dR <- gamma * I - mu * R
    dC <- omega * E          # Cumulative incidence tracker
    
    list(c(dS, dE, dI, dR, dC))
  })
}


# -------------------------------------------------------------------------
# STEP 3: Fixed Biological Parameters and Initial Conditions
# -------------------------------------------------------------------------

N0  <- 221234 # Total population of Zone Kirkos
dpw <- 7      # Time conversion unit (days per week)

# Literature fixed parameter values (per week)
fixed <- list( 
  mu    = 1 / (60 * 365 / dpw), # Natural mortality rate (60-year lifespan)
  omega = 1 / (11 / dpw),       # Incubation rate (11-day period)
  gamma = 1 / (20 / dpw),       # Recovery rate (20-day infectious period)
  b     = 1,                    # Baseline human recruitment
  sigma = 0.001                 # Disease-induced mortality rate
)

# Time points and observed cumulative cases
t_obs <- covid_obs$Week
y_obs <- covid_obs$CumCases

# Initial compartmental states
I0 <- y_obs[1]
E0 <- 8L

# TODO 3: Complete initial susceptible population S = N0 - I0 - E0
ic <- c(S = N0 - I0 - _______________?, E = E0, I = I0, R = 0L, C = I0)


# -------------------------------------------------------------------------
# STEP 4: Calibrate Model via Nonlinear Least Squares (nls.lm)
# -------------------------------------------------------------------------

# Function to run the ODE solver and return predicted cumulative cases (C)
obj_covid <- function(tspan, pars) {
  p   <- c(pars, fixed)
  out <- tryCatch(
    ode(y = ic, times = tspan, func = seir_covid, parms = p, method = "lsoda"),
    error = function(e) NULL
  )
  if (is.null(out)) return(rep(1e9, length(tspan)))
  out[match(tspan, out[, "time"]), "C"]
}

# Initial guess for transmission rate parameter beta
init_params <- c(beta = 0.2) 

# Run NLS calibration engine
fit_covid <- nls.lm(
  par     = init_params,
  fn      = function(p) obj_covid(t_obs, p) - y_obs,
  lower   = c(beta = 0),
  upper   = c(beta = 1),
  control = nls.lm.control(ftol = 1e-8, ptol = 1e-7, maxiter = 1000)
)

# Extract estimated beta parameter
theta_hat <- fit_covid$par

cat("── Calibrated Transmission Parameter (beta) ────\n")
print(round(theta_hat, 7))

# Generate predictions using fitted beta parameter
y_pred <- obj_covid(t_obs, theta_hat)


# -------------------------------------------------------------------------
# STEP 5: Calculate Goodness-of-Fit and Reproduction Number (R0)
# -------------------------------------------------------------------------

SS_res <- sum((y_obs - y_pred)^2)
SS_tot <- sum((y_obs - mean(y_obs))^2)

# TODO 4a: Calculate R-squared (1 - SS_res / SS_tot)
R2 <- 1 - (_______________? / SS_tot)
RMSE <- sqrt(mean((y_obs - y_pred)^2))

cat(sprintf("\n── Calibration Diagnostics ───────────────────\n"))
cat(sprintf("R^2  = %.4f\nRMSE = %.2f cases\n", R2, RMSE))

# Extract fixed parameters for R0 formula
mu    <- fixed$mu   
omega <- fixed$omega
gamma <- fixed$gamma
sigma <- fixed$sigma

# TODO 4b: Calculate the Basic Reproduction Number R0
# Formula: (beta * omega) / ((mu + omega) * (mu + sigma + gamma))
R0 <- (theta_hat["beta"] * omega) / ((mu + omega) * (mu + _______________? + gamma))

cat(sprintf("\nBasic Reproduction Number (R0) = %.6f\n", R0))
cat(ifelse(R0 > 1,
           "-> R0 > 1: Epidemic can expand. Public health interventions needed.\n",
           "-> R0 < 1: Epidemic will fade out over time.\n"))


# -------------------------------------------------------------------------
# STEP 6: Plot Calibrated Trajectory & Forecast
# -------------------------------------------------------------------------

# TODO 5: Pass the estimated parameter vector (theta_hat) into the plotting utility
plot_model_fit(
  ode_func = seir_covid,
  ic       = ic,
  fixed    = fixed,
  theta    = _______________?, # Pass optimal parameter estimates here
  t_obs    = t_obs,
  y_obs    = y_obs,
  state    = "C",
  title    = "SEIR Covid-19 Model Calibration - Zone Kirkos",
  xlabel   = "Epidemiological Week",
  ylabel   = "Cumulative Cases",
  forecast = 6
) +
  annotate(
    "text", x = 5, y = max(y_obs) * 2.5, hjust = 0, size = 3.5,
    label = sprintf("--Estimated--\nbeta = %.4f\n\n--Goodness of fit --\nR2 = %.4f\nRMSE = %.1f\nR0 = %.6f", 
                    theta_hat["beta"], R2, RMSE, R0)
  )


# -------------------------------------------------------------------------
# STEP 7: Save Outputs for Downstream Analyses
# -------------------------------------------------------------------------

# Create Outputs directory
dir.create("Outputs", showWarnings = FALSE)

# Save calibrated output bundle as an RDS file
saveRDS(
  list(
    theta_hat = theta_hat,
    fixed     = fixed,
    ic        = ic,
    t_obs     = t_obs,
    y_obs     = y_obs,
    R2        = R2,
    RMSE      = RMSE,
    R0        = R0
  ),
  file = "Outputs/covid_calibration_results_Zone_Kirkos.rds"
)

cat("\nSEIR COVID-19 model calibration outputs successfully saved to 'Outputs/' folder.\n")