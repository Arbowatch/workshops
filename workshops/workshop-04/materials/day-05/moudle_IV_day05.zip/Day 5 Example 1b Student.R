# =========================================================================
# Script: Day5_Example1b_Students.R
# Course: Day 5 — Sensitivity Analysis and Modelling Interventions
# Topic: Global Sensitivity Analysis (LHS & PRCC) of Malaria R0
# =========================================================================

# -------------------------------------------------------------------------
# 1. Load Required Libraries and Environment Setup
# -------------------------------------------------------------------------
if (!require("this.path")) install.packages("this.path")
source(file.path(this.path::this.dir(), "RSetupLibraries.R"))

# -------------------------------------------------------------------------
# 2. Load Calibrated Malaria Calibration Results (Ankasha Woreda)
# -------------------------------------------------------------------------
mal <- readRDS("Outputs/malaria_calibration_results_Ankasha_Woreda.rds")

# Unpack parameter objects
theta_mal <- mal$theta_mal
fixed_mal <- mal$fixed_mal
R0_mal    <- mal$R0_mal

cat("── Loaded Malaria Calibration Results ───────────────────────\n")
cat(sprintf("R2 = %.4f | RMSE = %.2f | Baseline R0 = %.3f\n", 
            mal$R2_mal, mal$RMSE_mal, R0_mal))


# -------------------------------------------------------------------------
# 3. Setup Latin Hypercube Sampling (LHS) Space
# -------------------------------------------------------------------------
set.seed(123)  # Set seed for reproducible sampling
N_lhs <- ________?   # Number of LHS iterations

# Uniform distribution parameter ranges
param_ranges <- data.frame(
  min = c(
    beta      = 0.05,
    alpha_vh  = 0.01,
    alpha_hv  = 0.10,
    sigma     = 1e-6,
    mu        = 0.00020,
    omega     = 0.10,
    gamma     = 1.00,
    kappa     = 0.20,
    mu_v      = 0.20,
    b         = 50,
    phi       = 1e6
  ),
  max = c(
    beta      = 0.80,
    alpha_vh  = 0.35,
    alpha_hv  = 1.00,
    sigma     = 1e-3,
    mu        = 0.00050,
    omega     = 1.00,
    gamma     = 3.00,
    kappa     = 1.00,
    mu_v      = 1.00,
    b         = 120,
    phi       = 1e7
  )
)


# TASK 1 [FILL IN THE BLANKS]: Generate and Scale LHS Sample Matrix
# -------------------------------------------------------------------------
# Step A: Draw random LHS samples in hypercube space [0, 1] using randomLHS()
# Step B: Scale unit values to real parameter boundaries: min + lhs * (max - min)

# FIXME: Generate raw LHS matrix (N_lhs rows, number of parameters as columns)
lhs_mat <- randomLHS(N_lhs, ______?(param_ranges))
colnames(lhs_mat) <- rownames(param_ranges)

# Transform unit samples to specified uniform parameter bounds
lhs_scaled <- lhs_mat
for (i in seq_len(ncol(lhs_mat))) {
  # FIXME: Scale column i using param_ranges$min and param_ranges$max
  lhs_scaled[, i] <- param_ranges$min[i] + ______?[, i] * (param_ranges$max[i] - param_ranges$min[i])
}


# -------------------------------------------------------------------------
# 4. Compute Vector-Borne Malaria R0 Across LHS Samples
# -------------------------------------------------------------------------

# TASK 2 [FILL IN THE BLANKS]: Evaluate Malaria R0 Dynamic Formula
# -------------------------------------------------------------------------
# Malaria R0 formula (square root of coupled human-vector transmission dynamics):
# R0 = sqrt( [ alpha_vh * alpha_hv * beta^2 * omega * kappa ] /
#            [ mu_v * (mu + omega) * (mu + sigma + gamma) * (mu_v + kappa) * mu_v ] *
#            [ phi / mu_v ] * [ mu / b ] )

R0_samples <- apply(lhs_scaled, 1, function(p) {
  tryCatch({
    sqrt(
      (
        # FIXME: Fill in missing vector-host parameters in numerator (alpha_vh, alpha_hv, beta, omega, kappa)
        p["alpha_vh"] * p["______?"] * p["beta"]^2 * p["______?"] * p["kappa"]
      ) /
        (
          # FIXME: Fill in vector mortality and human recovery terms in denominator
          p["mu_v"] * (p["mu"] + p["omega"]) * (p["mu"] + p["sigma"] + p["___"]) *
            (p["______?"] + p["kappa"]) * p["mu_v"]
        ) *
        (p["phi"] / p["mu_v"]) * (p["mu"] / p["b"])
    )
  }, error = function(e) {
    NA_real_
  })
})


# -------------------------------------------------------------------------
# 5. Compute Partial Rank Correlation Coefficients (PRCC)
# -------------------------------------------------------------------------

# Clean and combine LHS sample parameter matrix with outcome vector R0
lhs_df <- data.frame(lhs_scaled, R0 = R0_samples) |> na.omit()

# TASK 3 [FILL IN THE BLANKS]: Calculate Rank Correlations for PRCC
# -------------------------------------------------------------------------
# HINT: Apply rank transform to both outcome (lhs_df$R0) and parameter matrix

# FIXME: Calculate rank correlation between rank(lhs_df$R0) and rank of input parameters
prcc_vals <- cor(
  rank(______?$R0),
  apply(lhs_df[, rownames(param_ranges)], 2, rank)
)[1, ]


# -------------------------------------------------------------------------
# 6. Visualization: PRCC Tornado Plot
# -------------------------------------------------------------------------
df_prcc <- data.frame(
  Parameter = rownames(param_ranges),
  PRCC      = as.numeric(prcc_vals),
  Sig       = ifelse(abs(as.numeric(prcc_vals)) > 0.3, "Significant", "Negligible")
)

p_prcc <- ggplot(df_prcc |> arrange(abs(PRCC)),
                 aes(x = reorder(Parameter, abs(PRCC)), y = PRCC, fill = PRCC > 0)) +
  geom_col(width = 0.6) +
  geom_hline(yintercept = c(-0.3, 0.3), linetype = "dashed", colour = "grey50") +
  geom_hline(yintercept = 0, linewidth = 0.5) +
  coord_flip() +
  scale_fill_manual(
    values = c("TRUE" = "#C94A3F", "FALSE" = "#42529B"),
    labels = c("Negative effect", "Positive effect")
  ) +
  labs(
    title = "Global Sensitivity Analysis: PRCC of R0 (Malaria Model)",
    subtitle = "Dashed lines indicate |PRCC| = 0.3 significance threshold",
    x = "Model Parameter",
    y = "Partial Rank Correlation Coefficient (PRCC)",
    fill = "Effect Direction"
  ) +
  theme_arbo

print(p_prcc)