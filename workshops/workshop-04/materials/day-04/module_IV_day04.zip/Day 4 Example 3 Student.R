# ==============================================================================
# DAY 4 - EXAMPLE 3: Coupled SEI-SEIR Malaria Model Calibration (Student Template)
# File Name: Day4_Example3_Student.R
# Instructions: Complete each [TODO] prompt below during class.
# ==============================================================================

# Load Required Libraries and Setups (all stored in RSetupLibraries.R)
# -------------------------------------------------------------------------
if (!require("this.path")) install.packages("this.path")
source(file.path(this.path::this.dir(), "RSetupLibraries.R"))
# -------------------------------------------------------------------------

# -------------------------------------------------------------------------
# STEP 1: Load Real Weekly Malaria Surveillance Data
# -------------------------------------------------------------------------

# Load real weekly malaria dataset
mal_raw <- read_csv("Data/weekly_malaria_amh.csv")

# Filter dataset to 2024 data for Ankasha Woreda
mal_obs <- mal_raw %>%
  filter(year == 2024, woreda == "Ankasha") %>%
  arrange(epi_week)

# TODO 1: Calculate cumulative malaria cases using cumsum()
mal_obs$CumCases <- cumsum(mal_obs$_______________?)


# -------------------------------------------------------------------------
# STEP 2: Define Coupled SEI-SEIR Model Function
# -------------------------------------------------------------------------

sei_seir_malaria <- function(time, state, parms) {
  with(as.list(c(state, parms)), {
    N        <- SH + EH + IH + RH
    M        <- SV + EV + IV 
    
    # Force of infection (Vector -> Human and Human -> Vector)
    lambda_H <- alpha_vh * beta * IV / N     # Mosquitoes infecting humans
    lambda_V <- alpha_hv * beta * IH / N     # Humans infecting mosquitoes
    
    # Human compartments (SEIR)
    dSH <- b - lambda_H * SH - mu * SH
    dEH <- lambda_H * SH - (mu + omega) * EH
    
    # TODO 2a: Complete human infectious compartment equation (dIH)
    # Inflow from Exposed (omega*EH) minus mortality (mu + sigma) and recovery (gamma)
    dIH <- omega * EH - (mu + sigma + _______________?) * IH
    
    dRH <- gamma * IH - mu * RH
    dCH <- omega * EH   # Cumulative human cases tracker
    
    # Mosquito vector compartments (SEI)
    dSV <- phi - lambda_V * SV - mu_v * SV
    
    # TODO 2b: Complete vector exposed compartment equation (dEV)
    # Inflow from lambda_V * SV minus vector death (mu_v) and EIP transition (kappa)
    dEV <- lambda_V * SV - (mu_v + _______________?) * EV
    
    dIV <- kappa * EV - mu_v * IV
    
    list(c(dSH, dEH, dIH, dRH, dCH, dSV, dEV, dIV))
  })
}


# -------------------------------------------------------------------------
# STEP 3: Fixed Biological Parameters and Population Setup
# -------------------------------------------------------------------------

m  <- 40      # Vector-to-human ratio (40 mosquitoes per person)
N0 <- 265800  # Human population of Ankasha Woreda (2024)
M0 <- m * N0  # Total mosquito population

# Fixed parameter values (Weekly rates matching surveillance scale)
fixed_mal <- list(
  mu    = 1 / (60 * 52),     # Human mortality (60-year lifespan)
  omega = 1 / (14 / 7),      # Human incubation period (14 days -> 2 weeks)
  gamma = 1 / (4 / 7),       # Human recovery (4-day infectious period)
  kappa = 1 / (12 / 7),      # Vector extrinsic incubation period (12 days)
  mu_v  = 1 / (14 / 7),      # Vector lifespan (~14 days)
  b     = 1 / (60 * 52) * N0,# Human recruitment rate (~16.03 humans/week)
  phi   = 1 / (14 / 7) * M0  # Mosquito recruitment rate (40,000 mosquitoes/week)
)

# Initial conditions
Eh0 <- 50
Ih0 <- mal_obs$CumCases[1]
Rh0 <- 0
C0  <- mal_obs$CumCases[1]

Ev0 <- Eh0 * m
Iv0 <- Ih0 * m

# TODO 3: Complete initial susceptible human population (SH)
# Hint: SH = N0 - Eh0 - Ih0 - Rh0
mal_ic <- c(SH = N0 - Eh0 - _______________? - Rh0, EH = Eh0, IH = Ih0, RH = Rh0, CH = C0,
            SV = M0 - Ev0 - Iv0, EV = Ev0, IV = Iv0)


# -------------------------------------------------------------------------
# STEP 4: Calibrate Model Parameters via NLS (nls.lm)
# -------------------------------------------------------------------------

t_mal <- mal_obs$epi_week
y_mal <- mal_obs$CumCases

# Objective function returning predicted cumulative human cases (CH)
obj_malaria <- function(tspan, pars) {
  p   <- c(pars, fixed_mal)
  out <- tryCatch(
    ode(y = mal_ic, times = tspan, func = sei_seir_malaria, parms = p, method = "lsoda"),
    error = function(e) NULL
  )
  if (is.null(out)) return(rep(1e9, length(tspan)))
  out[match(tspan, out[, "time"]), "CH"]
}

# Initial parameter guesses: [biting rate, transmission efficiencies, disease death]
init_params <- c(beta = 0.3, alpha_vh = 0.1, alpha_hv = 0.3, sigma = 0.002)

# Fit model using Levenberg-Marquardt optimizer
fit_mal <- nls.lm(
  par     = init_params,
  fn      = function(p) obj_malaria(t_mal, p) - y_mal,
  lower   = c(beta = 0.01, alpha_vh = 1e-4, alpha_hv = 1e-4, sigma = 1e-5),
  upper   = c(beta = 1,    alpha_vh = 1,    alpha_hv = 1,    sigma = 1),
  control = nls.lm.control(ftol = 1e-8, ptol = 1e-7, maxiter = 1000)
)

theta_mal <- fit_mal$par
cat("── Estimated Malaria Parameters ─────────────────────\n")
print(round(theta_mal, 5))


# -------------------------------------------------------------------------
# STEP 5: Calculate Goodness-of-Fit, Vectorial Capacity, and R0
# -------------------------------------------------------------------------

y_pred_mal <- obj_malaria(t_mal, theta_mal)
R2_mal     <- 1 - sum((y_mal - y_pred_mal)^2) / sum((y_mal - mean(y_mal))^2)
RMSE_mal   <- sqrt(mean((y_mal - y_pred_mal)^2))

# Extract model rate parameters
mu_v  <- fixed_mal$mu_v; kappa <- fixed_mal$kappa
mu    <- fixed_mal$mu;   gamma <- fixed_mal$gamma
phi   <- fixed_mal$phi;  omega <- fixed_mal$omega

# Vectorial Capacity (VC)
VC_mal <- (theta_mal["alpha_vh"] * theta_mal["alpha_hv"] * theta_mal["beta"]^2) *
  (phi / (mu_v * N0)) * 
  (kappa / (mu_v + kappa)) / 
  (mu_v)

# TODO 4: Complete the R0 square root expression by multiplying transmission components
# Formula: sqrt( Transmission_Efficiencies * Vector_Host_Ratio * Human_EIP_Survival * Mosquito_EIP_Survival / (Lifespans) )
R0_mal <- sqrt(
  (theta_mal["alpha_vh"] * theta_mal["alpha_hv"] * theta_mal["beta"]^2) *
    (phi / (mu_v * N0)) * 
    (omega / (mu + omega)) * 
    (kappa / (mu_v + _______________?)) / 
    (mu_v * (mu + theta_mal["sigma"] + _______________?))
)

cat(sprintf("\n── Calibration Diagnostics ───────────────────\n"))
cat(sprintf("R^2                = %.4f\n", R2_mal))
cat(sprintf("RMSE               = %.2f cases\n", RMSE_mal))
cat(sprintf("Vectorial Capacity = %.3f\n", VC_mal))
cat(sprintf("Basic Rep. Number  = %.3f\n", R0_mal))


# -------------------------------------------------------------------------
# STEP 6: Visualizing Model Calibration & 5-Week Forecast
# -------------------------------------------------------------------------

plot_model_fit(
  ode_func = sei_seir_malaria,
  ic       = mal_ic,
  fixed    = fixed_mal,
  theta    = theta_mal,
  t_obs    = t_mal,
  y_obs    = y_mal,
  state    = "CH",
  title    = "SEI-SEIR Malaria Model Calibration -- Ankasha Woreda (2024)",
  xlabel   = "Epidemiological Week",
  ylabel   = "Cumulative Cases",
  forecast = 5
) +
  annotate(
    "text", x = 1, y = max(y_mal), hjust = 0, size = 3.5,
    label = sprintf("--Goodness of fit --\nR2 = %.4f\nRMSE = %.1f\nR0 = %.6f", 
                    R2_mal, RMSE_mal, R0_mal)
  )


# -------------------------------------------------------------------------
# STEP 7: Save Outputs for Downstream Analyses
# -------------------------------------------------------------------------

dir.create("Outputs", showWarnings = FALSE)

# Save output list object as RDS
saveRDS(
  list(
    theta_mal = theta_mal,
    fixed_mal = fixed_mal,
    mal_ic    = mal_ic,
    t_mal     = t_mal,
    y_mal     = y_mal,
    R2_mal    = R2_mal,
    RMSE_mal  = RMSE_mal,
    R0_mal    = R0_mal
  ),
  file = "Outputs/malaria_calibration_results_Ankasha_Woreda.rds"
)

cat("\nSEI-SEIR Malaria model calibration results successfully saved to 'Outputs/' folder.\n")