# =========================================================================
# Script: Day5_Example2c_Students.R
# Course: Day 5 — Advanced Dynamics & Sensitivity Analysis
# Topic: Malaria Vector Control (ITN & IRS) Dynamic Modeling & Cost-Effectiveness
# =========================================================================

# -------------------------------------------------------------------------
# 1. Load Required Libraries and Environment Setup
# -------------------------------------------------------------------------
if (!require("this.path")) install.packages("this.path")
source(file.path(this.path::this.dir(), "RSetupLibraries.R"))

# -------------------------------------------------------------------------
# 2. Load Saved Malaria Calibration Results (Ankasha Woreda)
# -------------------------------------------------------------------------
malaria.calibration.results <- readRDS("Outputs/malaria_calibration_results_Ankasha_Woreda.rds")

# Unpack calibrated parameter and state objects
theta_hat <- malaria.calibration.results$theta_mal
fixed     <- malaria.calibration.results$fixed_mal
ic        <- malaria.calibration.results$mal_ic

cat("── Loaded Malaria Calibration Initial States ───────────────\n")
cat(sprintf("Initial Human Susceptible (SH): %.0f | Initial Vector Susceptible (SV): %.0f\n", 
            ic["SH"], ic["SV"]))


# -------------------------------------------------------------------------
# 3. Dynamic SEI-SEIR Coupled Vector-Host Model with Vector Control
# -------------------------------------------------------------------------

# TASK 1 [FILL IN THE BLANKS]: Implement Dual Vector Control Dynamics
# -------------------------------------------------------------------------
# Biological Mechanisms:
# - ITNs block biting rate: beta_eff = beta * (1 - itn_t * eff_itn)
# - IRS increases adult vector mortality: mu_v_eff = mu_v + (irs_t * delta_irs)

sei_seir_malaria_vc <- function(time, state, parms) {
  with(as.list(c(state, parms)), {
    N <- SH + EH + IH + RH
    
    # Switch on interventions based on respective start weeks
    itn_t <- ifelse(time >= itn_start_week, itn, 0)
    irs_t <- ifelse(time >= irs_start_week, irs, 0)
    
    # FIXME: Calculate effective biting/transmission rate (beta_eff) with ITNs
    beta_eff <- beta * (1 - ___? * ___?)
    
    # FIXME: Calculate effective vector mortality (mu_v_eff) with IRS
    mu_v_eff <- mu_v + (___? * ___?)
    
    # Forces of infection
    Lambda_H <- alpha_vh * beta_eff * IV / N
    Lambda_V <- alpha_hv * beta_eff * IH / N
    
    # Human SEIR differential equations
    dSH <- b           - Lambda_H * SH - mu * SH
    dEH <- Lambda_H * SH - (mu + omega) * EH
    dIH <- omega * EH    - (mu + sigma + gamma) * IH
    dRH <- gamma * IH    - mu * RH
    dCH <- omega * EH  # Cumulative human case tracker
    
    # Mosquito SEI differential equations
    dSV <- phi         - Lambda_V * SV  - mu_v_eff * SV
    dEV <- Lambda_V * SV - (mu_v_eff + kappa) * EV
    dIV <- kappa * EV    - mu_v_eff * IV
    
    list(c(dSH, dEH, dIH, dRH, dCH, dSV, dEV, dIV))
  })
}


# -------------------------------------------------------------------------
# 4. Run Multi-Scenario Vector Control Simulations
# -------------------------------------------------------------------------

itn_start_week <- 10
irs_start_week <- 20
tspan <- 1:60  # Weeks 1 to 60

# TASK 2 [FILL IN THE BLANKS]: Scenario Wrapper Function
# -------------------------------------------------------------------------
run_malaria_vector_control <- function(itn, irs, label, itn_start_week = 10, irs_start_week = 20) {
  p <- c(
    theta_hat, 
    fixed,
    itn            = itn,      
    eff_itn        = 0.50,    # 50% physical biting block efficacy
    irs            = irs,      
    delta_irs      = 0.05,    # 5% added weekly vector mortality
    itn_start_week = itn_start_week,
    irs_start_week = irs_start_week
  )
  
  # FIXME: Solve coupled system via ode()
  out <- ode(y = ic, times = tspan, func = ___?, parms = p, method = "lsoda")
  
  data.frame(
    Week     = out[, "time"], 
    IH       = out[, "IH"], 
    CumC     = out[, "CH"], 
    Scenario = label
  )
}

# Bind baseline and combination scenarios
vc_df <- bind_rows(
  run_malaria_vector_control(itn = 0.0, irs = 0.0, label = "Baseline"),
  run_malaria_vector_control(itn = 0.1, irs = 0.0, label = "ITN 10%"),
  run_malaria_vector_control(itn = 0.0, irs = 0.3, label = "IRS 30%"),
  run_malaria_vector_control(itn = 0.1, irs = 0.3, label = "ITN 10% + IRS 30%"),
  run_malaria_vector_control(itn = 0.2, irs = 0.6, label = "ITN 20% + IRS 60%")
)


# -------------------------------------------------------------------------
# 5. Visualization: Dual-Panel Dynamics & Cases Averted Bar Chart
# -------------------------------------------------------------------------

# Panel 1: Infectious Human Trajectories
p1 <- ggplot(vc_df, aes(Week, IH, colour = Scenario)) +
  geom_line(linewidth = 1.1) +
  geom_vline(xintercept = itn_start_week, linetype = "dashed", colour = "forestgreen") +
  geom_vline(xintercept = irs_start_week, linetype = "dashed", colour = "steelblue") +
  annotate("text", x = itn_start_week + 0.5, y = max(vc_df$IH) * 0.95,
           hjust = 0, size = 3.2, colour = "forestgreen",
           label = sprintf("ITN start\nweek %d", itn_start_week)) +
  annotate("text", x = irs_start_week + 0.5, y = max(vc_df$IH) * 0.80,
           hjust = 0, size = 3.2, colour = "steelblue",
           label = sprintf("IRS start\nweek %d", irs_start_week)) +
  guides(colour = guide_legend(
    ncol = 2, byrow = TRUE,
    keywidth = unit(1.2, "cm"), keyheight = unit(1.0, "cm"),
    label.theme = element_text(size = 9, lineheight = 1.2)
  )) +
  labs(
    title = sprintf("Infectious Malaria Cases Under Vector Control\n(ITN from wk %d, IRS from wk %d)",
                    itn_start_week, irs_start_week),
    x = "Week", y = "Infectious Humans (IH)", colour = "Scenario"
  ) +
  theme_arbo +
  theme(legend.position = "bottom", legend.title = element_text(face = "bold"))

# Panel 2: Percentage Reduction Bar Chart
averted <- vc_df %>% 
  group_by(Scenario) %>%
  summarise(TotalCases = max(CumC), .groups = "drop") %>%
  mutate(
    Averted    = max(TotalCases) - TotalCases,
    PctReduced = round(100 * Averted / max(TotalCases), 1),
    PctLabel   = sprintf("%.1f%%", PctReduced)
  )

p2 <- ggplot(averted, aes(x = reorder(Scenario, PctReduced), y = PctReduced, fill = Scenario)) +
  geom_col(show.legend = FALSE) +
  geom_text(aes(label = PctLabel), hjust = -0.2, size = 3.5, fontface = "bold") +
  coord_flip() +
  scale_y_continuous(limits = c(0, max(averted$PctReduced) * 1.25)) +
  scale_x_discrete(labels = function(x) gsub("\n", " ", x)) +
  labs(title = "Cases Averted (%)", x = "", y = "% Reduction") +
  theme_arbo

# Display side-by-side
grid.arrange(p1, p2, ncol = 2)


# -------------------------------------------------------------------------
# 6. Timing Sensitivity Experiments
# -------------------------------------------------------------------------

# Experiment 4a: Delay ITN deployment by 5 weeks (Week 15 vs Week 10)
itn_delay <- 5

run_prompt_itn <- run_malaria_vector_control(
  itn = 0.1, irs = 0.0, label = "Prompt ITN (Week 10)",
  itn_start_week = 10, irs_start_week = 20
)

run_delayed_itn <- run_malaria_vector_control(
  itn = 0.1, irs = 0.0, label = "Delayed ITN (Week 15)",
  itn_start_week = 10 + itn_delay, irs_start_week = 20
)

add_cases_delay <- max(run_delayed_itn$CumC) - max(run_prompt_itn$CumC)

cat("\n── Timing Experiment 4a Results ───────────────────────────\n")
cat(sprintf("Prompt ITN (Week 10) Cases:  %.0f\n", max(run_prompt_itn$CumC)))
cat(sprintf("Delayed ITN (Week 15) Cases: %.0f\n", max(run_delayed_itn$CumC)))
cat(sprintf("Additional Cases from 5-Week Delay: %.0f cases\n", add_cases_delay))


# Experiment 4b: Simultaneous vs Staggered Deployment
run_staggered <- run_malaria_vector_control(
  itn = 0.1, irs = 0.3, label = "Staggered (ITN Wk 10, IRS Wk 20)",
  itn_start_week = 10, irs_start_week = 20
)

run_simultaneous <- run_malaria_vector_control(
  itn = 0.1, irs = 0.3, label = "Simultaneous (ITN Wk 10, IRS Wk 10)",
  itn_start_week = 10, irs_start_week = 10
)

diff_deployment <- max(run_staggered$CumC) - max(run_simultaneous$CumC)

cat("\n── Timing Experiment 4b Results ───────────────────────────\n")
cat(sprintf("Staggered Deployment Cases:    %.0f\n", max(run_staggered$CumC)))
cat(sprintf("Simultaneous Deployment Cases: %.0f\n", max(run_simultaneous$CumC)))
cat(sprintf("Additional Cases Averted via Simultaneous Start: %.0f cases\n", diff_deployment))


# -------------------------------------------------------------------------
# 7. Cost-Effectiveness Analysis
# -------------------------------------------------------------------------

# TASK 3 [FILL IN THE BLANKS]: Compute Cost Per Case Averted
# -------------------------------------------------------------------------
people_per_household <- 3
total_human_pop       <- sum(ic[c("SH", "EH", "IH", "RH")])
total_households      <- total_human_pop / people_per_household

cost_itn_per_hh <- 8  # $8 per net (1 net per household)
cost_irs_per_hh <- 5  # $5 per household

baseline_cases <- max(vc_df$CumC[vc_df$Scenario == "Baseline"])

cost_table <- vc_df %>%
  group_by(Scenario) %>%
  summarise(TotalCases = max(CumC), .groups = "drop") %>%
  mutate(
    CasesAverted = baseline_cases - TotalCases,
    
    # Assign intervention unit costs
    Cost_per_HH = case_when(
      Scenario == "Baseline"            ~ 0,
      Scenario == "ITN 10%"             ~ cost_itn_per_hh,
      Scenario == "IRS 30%"             ~ cost_irs_per_hh,
      Scenario == "ITN 10% + IRS 30%"   ~ cost_itn_per_hh + cost_irs_per_hh,
      Scenario == "ITN 20% + IRS 60%"   ~ cost_itn_per_hh + cost_irs_per_hh,
      TRUE                              ~ 0
    ),
    
    # FIXME: Compute Total Program Cost = Cost_per_HH * total_households
    TotalProgramCost = ___? * ___?,
    
    # FIXME: Compute Cost per Case Averted = TotalProgramCost / CasesAverted
    CostPerCaseAverted = ifelse(CasesAverted > 0, ___? / ___?, NA)
  )

kable(
  cost_table, 
  col.names = c("Scenario", "Total Cases", "Cases Averted", "Cost per Household ($)", "Total Program Cost ($)", "Cost Per Case Averted ($)"),
  caption = "Table 1: Cost-Effectiveness Evaluation of Malaria Vector Control Scenarios"
) %>% kable_styling(full_width = FALSE)