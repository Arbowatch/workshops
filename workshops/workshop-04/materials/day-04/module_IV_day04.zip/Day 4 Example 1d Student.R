# ==============================================================================
# DAY 4 - EXAMPLE 1D: Bayesian Calibration via MCMC (Student Template)
# File Name: Day4_Example1d_Student.R
# Instructions: Complete each [TODO] prompt below during class.
# ==============================================================================

# Load Required Libraries and Setups (all stored in RSetupLibraries.R)
# -------------------------------------------------------------------------
if (!require("this.path")) install.packages("this.path")
source(file.path(this.path::this.dir(), "RSetupLibraries.R"))
# -------------------------------------------------------------------------

# -------------------------------------------------------------------------
# Step 0: Import Epidemic Data
# -------------------------------------------------------------------------

# Load synthetic dataset from Excel
epi_data <- read_excel("Data/SyntheticEpidemicData.xlsx")

Weeks    <- epi_data$epi_week
observed <- epi_data$reported_cases

t <- Weeks
cumObsCases <- cumsum(observed)


# -------------------------------------------------------------------------
# Step 1: Define the Objective Function
# -------------------------------------------------------------------------

# Gaussian model function returning cumulative predicted cases
objectiveFunc <- function(params, t) {
  a <- params[1]
  b <- params[2]
  c <- params[3]
  
  I <- a * exp(-0.5 * ((t - b) / c)^2)
  return(cumsum(I))
}


# -------------------------------------------------------------------------
# Step 2: Bayesian Calibration Setup & MCMC Sampler
# -------------------------------------------------------------------------

# Initial parameter choices: [a, b, c, sigma]
params_init <- c(550, 10, 2, 50) 

lb <- c(0, 0, 0, 0.01)       # Lower bounds
ub <- c(1000, 50, 10, 500)   # Upper bounds

# MCMC Tuning Settings
n_steps      <- 40000        # Total MCMC iterations
burn_in      <- 15000        # Discard initial warmup iterations
proposal_std <- c(5.0, 0.1, 0.05, 1.5) # Step sizing for random walk

# TODO 1: Complete the Uniform Prior evaluation
# Return -Inf if parameters violate bounds [lb, ub], else return 0
computeLogPrior <- function(params, lb, ub) {
  if (any(params < lb) || any(params > ub)) {
    return(_______________?) # Reject proposal if outside bounds
  } else {
    return(0)    # Uniform uninformative prior
  }
}

# Evaluates log-likelihood assuming Gaussian measurement error (sigma)
computeLogLikelihood <- function(params, t_data, y_observed) {
  theta  <- params[1:3]
  sigma  <- params[4]
  y_pred <- objectiveFunc(theta, t_data)
  
  n <- length(y_observed)
  logL <- - (n/2) * log(2 * pi * sigma^2) - (1 / (2 * sigma^2)) * sum((y_observed - y_pred)^2)
  return(logL)
}

# Core Metropolis-Hastings Engine
runMH <- function(t_data, y_obs, init, lb, ub, steps, step_sizes) {
  n_vars <- length(init)
  chain  <- matrix(0, nrow = steps, ncol = n_vars)
  chain[1, ] <- init
  
  current_p <- init
  current_logPost <- computeLogPrior(current_p, lb, ub) + computeLogLikelihood(current_p, t_data, y_obs)
  accepted <- 0
  
  for (s in 2:steps) {
    # Propose a new state via Gaussian random walk
    proposal <- current_p + rnorm(n_vars, mean = 0, sd = step_sizes)
    
    prior_val <- computeLogPrior(proposal, lb, ub)
    if (is.infinite(prior_val)) {
      proposed_logPost <- -Inf
    } else {
      proposed_logPost <- prior_val + computeLogLikelihood(proposal, t_data, y_obs)
    }
    
    # Compute acceptance probability ratio
    log_alpha <- proposed_logPost - current_logPost
    
    if (log(runif(1)) < log_alpha) {
      current_p <- proposal
      current_logPost <- proposed_logPost
      accepted <- accepted + 1
    }
    
    chain[s, ] <- current_p
  }
  
  acceptance_rate <- accepted / (steps - 1)
  return(list(chain = chain, acceptance_rate = acceptance_rate))
}

# Run the Metropolis-Hastings Sampler
cat("Running Metropolis-Hastings MCMC...\n")
mcmc_results <- runMH(t, cumObsCases, params_init, lb, ub, n_steps, proposal_std)
cat(sprintf("MCMC Finished. Acceptance Rate: %.2f%%\n", mcmc_results$acceptance_rate * 100))

# Discard burn-in iterations to keep the posterior distribution
clean_chain <- mcmc_results$chain[burn_in:n_steps, ]


# -------------------------------------------------------------------------
# Step 3: Extract Posterior Means
# -------------------------------------------------------------------------

# TODO 2: Extract point estimates by calculating column means of the clean chain
# Hint: Use colMeans() on clean_chain
params_optimal <- colMeans(_______________?)

cat("\n── Posterior Means (a, b, c, sigma) ───────────\n")
print(params_optimal)


# -------------------------------------------------------------------------
# Step 4: Model Output and Goodness-of-Fit
# -------------------------------------------------------------------------

I_cum_t  <- objectiveFunc(params_optimal[1:3], t)
rmse     <- sqrt(mean((cumObsCases - I_cum_t)^2))
mae      <- mean(abs(cumObsCases - I_cum_t))
SStot    <- sum((cumObsCases - mean(cumObsCases))^2)
SSres    <- sum((cumObsCases - I_cum_t)^2)
r2       <- 1 - SSres / SStot
spearman <- cor(cumObsCases, I_cum_t, method = "spearman")


# -------------------------------------------------------------------------
# Step 5: Uncertainty Propagation (95% Credible Intervals)
# -------------------------------------------------------------------------

n_samples_to_plot <- 200
sample_indices    <- sample(1:nrow(clean_chain), n_samples_to_plot, replace = FALSE)
sampled_curves    <- matrix(0, nrow = n_samples_to_plot, ncol = length(t))

for (idx in 1:n_samples_to_plot) {
  p_sampled <- clean_chain[sample_indices[idx], 1:3]
  sampled_curves[idx, ] <- objectiveFunc(p_sampled, t)
}

# TODO 3: Compute lower (2.5%) and upper (97.5%) quantiles across sampled curves
# Hint: Use apply() with quantile function across margin 2 (columns)
ci_lower <- apply(sampled_curves, 2, quantile, probs = 0.025)
ci_upper <- apply(sampled_curves, 2, quantile, probs = _______________?) # Fill in upper probability percentile


# -------------------------------------------------------------------------
# Step 6: Visualizing MCMC Calibration and Credible Intervals
# -------------------------------------------------------------------------

# Reset plotting window
par(mfrow = c(1,1))

plot(t, cumObsCases, type = "n", xlim = range(t), ylim = c(0, max(ci_upper, cumObsCases)),
     xlab = "Epidemic Week", ylab = "Cumulative Cases", 
     main = "MCMC Calibration of Epidemic Model to Cumulative Data")

# Plot shaded 95% Credible Interval region
polygon(c(t, rev(t)), c(ci_lower, rev(ci_upper)), col = rgb(0.8, 0.92, 0.8, 0.6), border = FALSE)

# Initial (uncalibrated) model prediction
I_init <- objectiveFunc(params_init[1:3], t)

# TODO 4: Add the calibrated model line (I_cum_t) in darkgreen
# Hint: Use lines(x_vector, y_vector, ...)
points(t, cumObsCases, col = "black", pch = 16)
lines(t, I_init, col = "red", lty = 2, lwd = 1.2)
lines(t, _______________?, col = "darkgreen", lty = 1, lwd = 2)

legend("bottomright", 
       legend = c("95% Credible Interval", "Observed Data", "Unfitted Model", "MCMC Calibrated Model"),
       col    = c(rgb(0.8, 0.92, 0.8), "black", "red", "darkgreen"), 
       lty    = c(NA, NA, 2, 1), 
       pch    = c(15, 16, NA, NA), 
       bty    = "o")

# Print summary overlay text block
txt <- sprintf(
  "Calibrated Parameters (Posterior Mean):\na = %.2f\nb = %.2f\nc = %.2f\nsigma = %.2f\n\nGoodness-of-Fit:\nRMSE = %.2f\nMAE = %.4f\nR^2 = %.4f\nCor = %.4f",
  params_optimal[1], params_optimal[2], params_optimal[3], params_optimal[4],
  rmse, mae, r2, spearman
)
text(x = min(t), y = max(ci_upper) * 0.95, labels = txt, adj = c(0, 1), cex = 0.85)