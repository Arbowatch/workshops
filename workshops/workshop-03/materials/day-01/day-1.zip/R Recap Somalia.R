## Introduction to R for Public Health
## Module ARBO-WATCH PROJECT: CAPACITY BUILDING
## Module II
## Recap using a malaria time-series dataset
## author: "JKUAT"

# Load required packages for the session
library(readr)
library(dplyr)
library(ggplot2)

# Import dataset: change this section to reflect on your drive/project
malaria <- read_csv("data/malaria_dataset.csv")

# Inspect dataset
head(malaria)
str(malaria)
summary(malaria)
dim(malaria)

# Extract vectors and basic summaries
cases <- malaria$malaria_counts
rain <- malaria$rainfall

mean(cases, na.rm = TRUE)
median(cases, na.rm = TRUE)
max(cases, na.rm = TRUE)
mean(rain, na.rm = TRUE)

# Select key variables
malaria %>%
  select(year, Months, malaria_counts, rainfall, mean_temp) %>%
  head()

# Filter examples
malaria %>% 
  filter(year == 2023)

malaria %>% 
  filter(malaria_counts > 3000)

malaria %>% 
  filter(rainfall > 200)

# Create new variables
malaria <- malaria %>%
  mutate(
    high_malaria = ifelse(malaria_counts > 3000, "High", "Lower"),
    high_rainfall = ifelse(rainfall > 150, "High", "Low"),
    temp_range = max_temp - min_temp
  )

# Summarise by year
year_summary <- malaria %>%
  group_by(year) %>%
  summarise(
    total_cases = sum(malaria_counts, na.rm = TRUE),
    mean_rainfall = mean(rainfall, na.rm = TRUE),
    mean_temp = mean(mean_temp, na.rm = TRUE)
  )
print(year_summary)

# Monthly burden
month_summary <- malaria %>%
  group_by(Months) %>%
  summarise(mean_cases = mean(malaria_counts, na.rm = TRUE)) %>%
  arrange(desc(mean_cases))
print(month_summary)

# Plot malaria counts by month number
ggplot(malaria, aes(x = Month, y = malaria_counts)) +
  geom_line() +
  geom_point() +
  labs(title = "Malaria counts over time (Month index)",
       x = "Month", y = "Cases") +
  theme_minimal()

# Plot rainfall vs malaria
ggplot(malaria, aes(x = rainfall, y = malaria_counts)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Rainfall vs Malaria Cases",
       x = "Rainfall", y = "Cases") +
  theme_minimal()

# Convert date
malaria <- malaria %>%
  mutate(date = as.Date(date, format = "%d/%m/%Y"))

# Time series plot using date
ggplot(malaria, aes(x = date, y = malaria_counts)) +
  geom_line() +
  geom_point() +
  labs(title = "Malaria counts over time",
       x = "Date", y = "Cases") +
  theme_minimal()

# Correlation analysis
cor_matrix <- malaria %>%
  select(malaria_counts, rainfall, mean_temp, mean_humidity, mean_wind)
cor(cor_matrix)
#round to two decimal points
round(cor(cor_matrix),2)
pairs(cor_matrix)



# Linear model
model1 <- lm(malaria_counts ~ rainfall + mean_temp + mean_humidity,
             data = malaria)
summary(model1)

# Create reusable function
classify_cases <- function(x) {
  ifelse(x > 3000, "High burden", "Lower burden")
}

# Apply function
malaria <- malaria %>%
  mutate(case_category = classify_cases(malaria_counts))

# Missing values check
colSums(is.na(malaria))

# Summary statistics
malaria %>%
  summarise(
    mean_cases = mean(malaria_counts, na.rm = TRUE),
    sd_cases = sd(malaria_counts, na.rm = TRUE),
    mean_rain = mean(rainfall, na.rm = TRUE),
    mean_temp = mean(mean_temp, na.rm = TRUE),
    mean_humidity = mean(mean_humidity, na.rm = TRUE)
  )

# Yearly trend plot
yearly_summary <- malaria %>%
  group_by(year) %>%
  summarise(total_cases = sum(malaria_counts, na.rm = TRUE))

ggplot(yearly_summary, aes(x = year, y = total_cases)) +
  geom_line() +
  geom_point() +
  labs(title = "Total malaria cases by year",
       x = "Year", y = "Total cases") +
  theme_minimal()



