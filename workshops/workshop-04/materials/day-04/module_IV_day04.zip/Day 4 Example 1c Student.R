# ==============================================================================
# DAY 4 - EXAMPLE 1C: Maximum Likelihood Estimation (MLE) (Student Template)
# File Name: Day4_Example1c_Student.R
# Instructions: Complete each [TODO] prompt below during class.
# ==============================================================================

# Load Required Libraries and Setups (all stored in RSetupLibraries.R)
# -------------------------------------------------------------------------
if (!require("this.path")) install.packages("this.path")
source(file.path(this.path::this.dir(), "RSetupLibraries.R"))
# -------------------------------------------------------------------------

# -------------------------------------------------------------------------
# Step 0: Import Epidemic Data
# -------------------------------------------------------------------------

# Load synthetic dataset from Excel
epi_data <- read_excel("Data/SyntheticEpidemicData.xlsx")

Weeks    <- epi_data$epi_week
observed <- epi_data$reported_cases

t <- Weeks
cumObsCases <- cumsum(observed)


# -------------------------------------------------------------------------
# Step 1: Define Objective Function
# -------------------------------------------------------------------------

# Gaussian model function: I(t) = a * exp(-0.5 * ((t - b)/c)^2)
objectiveFunction <- function(params, t) {
  a <- params[1]
  b <- params[2]
  c <- params[3]
  
  # Calculate expected cases (model prediction)
  model <- a * exp(-0.5 * ((t - b) / c)^2)
  
  # Avoid non-positive values to prevent log(0) errors
  model[model < .Machine$double.eps] <- .Machine$double.eps
  return(model)
}


# -------------------------------------------------------------------------
# Step 2: Poisson Negative Log-Likelihood Function
# -------------------------------------------------------------------------

# TODO 1: Complete the Poisson Negative Log-Likelihood expression
# Formula: -sum(observed * log(model_pred) - model_pred)
negativeLogLikelihood <- function(params) {
  model_pred <- objectiveFunction(params, t)
  
  # Fill in the Poisson NLL loss function:
  -sum(_______________? * log(model_pred) - _______________?)
}


# -------------------------------------------------------------------------
# Step 3: Set Parameter Bounds and Initial Guesses
# -------------------------------------------------------------------------

params0     <- c(a = 550, b = 10, c = 2)
lowerBounds <- c(1, 1, 0.1)
upperBounds <- c(1000, 50, 20)


# -------------------------------------------------------------------------
# Step 4: Maximum Likelihood Estimation via optim()
# -------------------------------------------------------------------------

# TODO 2: Complete the call to optim() by supplying our loss function
fit <- optim(
  par     = params0,
  fn      = _______________?,  # Pass the negative log-likelihood function here
  method  = "L-BFGS-B",
  lower   = lowerBounds,
  upper   = upperBounds,
  control = list(trace = 1, maxit = 1000)
)


# -------------------------------------------------------------------------
# Step 5: Extract Optimal Parameters
# -------------------------------------------------------------------------

# TODO 3: Extract optimal parameters from the fit object
# Hint: In optim(), estimated parameters are stored in fit$par
params_optimal <- fit$_______________?

cat("\n── MLE Optimal Parameters ───────────────────\n")
print(params_optimal)


# -------------------------------------------------------------------------
# Step 6: Model Predictions and Cumulative Sums
# -------------------------------------------------------------------------

# Fitted predictions using optimal parameters
I_fit_obs <- objectiveFunction(params_optimal, t)
cumFitObs <- cumsum(I_fit_obs)

# Initial (uncalibrated) predictions
I_init_obs  <- objectiveFunction(params0, t)
cumPredCases <- cumsum(I_init_obs)


# -------------------------------------------------------------------------
# Step 7: Goodness-of-Fit Statistics
# -------------------------------------------------------------------------

RMSE  <- sqrt(mean((cumObsCases - cumFitObs)^2))
MAE   <- mean(abs(cumObsCases - cumFitObs))
SStot <- sum((cumObsCases - mean(cumObsCases))^2)
SSres <- sum((cumObsCases - cumFitObs)^2)
R2    <- 1 - (SSres / SStot)

# TODO 4: Calculate Spearman correlation between observed and fitted cumulative cases
correlation <- cor(cumObsCases, _______________?, method = "spearman")
pvalue      <- cor.test(cumObsCases, cumFitObs, method = "spearman")$p.value

# Print GoF Statistics
cat("\n── Goodness-of-Fit Summary ───────────────────\n")
cat(sprintf("RMSE                 = %.4f\n", RMSE))
cat(sprintf("MAE                  = %.4f\n", MAE))
cat(sprintf("R^2                  = %.4f\n", R2))
cat(sprintf("Spearman Correlation = %.4f\n", correlation))
cat(sprintf("p-value              = %.4e\n", pvalue))


# -------------------------------------------------------------------------
# Step 8: Visualization of Calibration
# -------------------------------------------------------------------------

plotData <- data.frame(
  Week     = t,
  Observed = cumObsCases,
  Initial  = cumPredCases,
  Fitted   = cumFitObs
)

ggplot(plotData, aes(x = Week)) +
  geom_point(aes(y = Observed, shape = "Observed Data"), size = 2) +
  geom_line(aes(y = Initial, color = "Unfitted Model"), linetype = "dashed", linewidth = 1) +
  geom_line(aes(y = Fitted, color = "MLE Calibrated Model"), linewidth = 1.2) +
  scale_color_manual(
    name   = NULL,
    values = c("Unfitted Model" = "blue", "MLE Calibrated Model" = "red")
  ) +
  scale_shape_manual(
    name   = NULL,
    values = c("Observed Data" = 16)
  ) +
  guides(
    color = guide_legend(order = 2, override.aes = list(linetype = c("dashed", "solid"))),
    shape = guide_legend(order = 1)
  ) +
  labs(
    title = "Calibration of the Epidemic Model Using Maximum Likelihood Estimation",
    x     = "Epidemic Week",
    y     = "Cumulative Cases"
  ) +
  annotate(
    "text",
    x = min(t),
    y = max(cumObsCases),
    hjust = 0,
    vjust = 1,
    label = paste(
      "Optimal Parameters",
      sprintf("\na = %.2f", params_optimal[1]),
      sprintf("\nb = %.2f", params_optimal[2]),
      sprintf("\nc = %.2f", params_optimal[3]),
      sprintf("\n\nRMSE = %.2f", RMSE),
      sprintf("\nMAE = %.2f", MAE),
      sprintf("\nR^2 = %.4f", R2),
      sprintf("\nSpearman = %.4f", correlation),
      sep = ""
    )
  ) +
  theme_bw() +
  theme(
    legend.position = "inside",
    legend.position.inside = c(0.95, 0.05),
    legend.justification = c(1, 0),
    legend.background = element_rect(color = "black", fill = "white", linewidth = 0.5),
    legend.margin = margin(6, 6, 6, 6)
  )


# -------------------------------------------------------------------------
# Step 9: Print Optimization Convergence Summary
# -------------------------------------------------------------------------

cat("\n── Optimization Diagnostic ───────────────────\n")
cat("Convergence Code (0 = Successful):", fit$convergence, "\n")
cat("Final Negative Log-Likelihood:   ", fit$value, "\n")